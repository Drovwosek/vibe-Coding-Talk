VPN Box

1. Unzip this archive.
2. Open install.bat / install.command.
3. The VPN profile will be opened in your default client.
4. If the system has no VPN client yet, install OpenVPN Connect once and run the script again.
