@echo off
setlocal
set "BOX_DIR=%~dp0"
if not exist "%BOX_DIR%vpn-box" mkdir "%BOX_DIR%vpn-box"
copy /Y "%BOX_DIR%vpn-box.ovpn" "%BOX_DIR%vpn-box\vpn-box.ovpn" >nul
start "" "%BOX_DIR%vpn-box\vpn-box.ovpn"
