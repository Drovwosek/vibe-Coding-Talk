#!/bin/bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$DIR/vpn-box"
cp "$DIR/vpn-box.ovpn" "$DIR/vpn-box/vpn-box.ovpn"
open "$DIR/vpn-box/vpn-box.ovpn"
